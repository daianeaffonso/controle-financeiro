import { RouterOutlet } from '@angular/router';
import { v4 as uuidv4 } from "uuid";
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ControleFinanceiroComponent } from './pages/controle-financeiro/controle-financeiro.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule, FormsModule, ControleFinanceiroComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'controle-financeiro';
  public uuid: string = uuidv4();

}