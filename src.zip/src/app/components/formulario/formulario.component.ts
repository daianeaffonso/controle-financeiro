import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-formulario',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './formulario.component.html',
  styleUrl: './formulario.component.css'
})
export class FormularioComponent {
  descricao = '';
  tipo = 'Entrada';
  valor: number | null = null;

  // Emite apenas os campos preenchidos; o pai gera o id e adiciona data/categoria
  @Output() novoRegistro = new EventEmitter<{ descricao: string; tipo: string; valor: number }>();

  adicionarRegistro() {
    if (!this.descricao.trim() || this.valor === null || this.valor <= 0) {
      window.alert("Preencha todos os campos corretamente para adicionar um registro.");
      return;
    }

    const dados = {
      descricao: this.descricao.trim(),
      tipo: this.tipo,
      valor: this.valor,
    };

    this.novoRegistro.emit(dados);
    this.resetForm();
  }

  resetForm() {
    this.descricao = '';
    this.tipo = 'Entrada';
    this.valor = null;
  }
}
