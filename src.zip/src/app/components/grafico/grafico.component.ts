import { Component, Input, OnChanges, SimpleChanges, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Chart, ChartConfiguration, registerables } from 'chart.js';

// Registra todos os componentes do Chart.js
Chart.register(...registerables);

@Component({
  selector: 'app-grafico',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './grafico.component.html',
  styleUrl: './grafico.component.css'
})
export class GraficoComponent implements AfterViewInit, OnChanges {
  @ViewChild('chartCanvas', { static: false }) chartCanvas!: ElementRef<HTMLCanvasElement>;
  @Input() receita: number = 0;
  @Input() despesa: number = 0;
  @Input() investimento: number = 0;

  chart: Chart<'doughnut'> | null = null;

  ngAfterViewInit(): void {
    this.atualizarGrafico();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ((changes['receita'] || changes['despesa'] || changes['investimento']) && this.chartCanvas) {
      this.atualizarGrafico();
    }
  }

  atualizarGrafico(): void {
    if (!this.chartCanvas || !this.chartCanvas.nativeElement) {
      console.warn('Canvas não encontrado');
      return;
    }

    const ctx = this.chartCanvas.nativeElement.getContext('2d');
    if (!ctx) {
      console.warn('Context 2D não disponível');
      return;
    }

    // Destruir gráfico anterior
    if (this.chart) {
      this.chart.destroy();
    }

    const config: ChartConfiguration<'doughnut'> = {
      type: 'doughnut',
      data: {
        labels: ['Receitas', 'Despesas', 'Investimentos'],
        datasets: [
          {
            data: [this.receita, this.despesa, this.investimento],
            backgroundColor: ['#4CAF50', '#F44336', '#2196F3'],
            borderColor: ['#45a049', '#da190b', '#0b7dda'],
            borderWidth: 2
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            position: 'bottom' as const,
            labels: {
              font: { size: 14 },
              padding: 20
            }
          },
          tooltip: {
            callbacks: {
              label: (context) => {
                const label = context.label || '';
                const value = new Intl.NumberFormat('pt-BR', {
                  style: 'currency',
                  currency: 'BRL'
                }).format(context.parsed as number);
                return `${label}: ${value}`;
              }
            }
          }
        }
      }
    };

    this.chart = new Chart(ctx, config);
  }
}
