import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaResumoComponent } from './lista-resumo.component';

describe('ListaResumoComponent', () => {
  let component: ListaResumoComponent;
  let fixture: ComponentFixture<ListaResumoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ListaResumoComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ListaResumoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
