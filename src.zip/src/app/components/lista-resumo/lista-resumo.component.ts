import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { GraficoComponent } from '../grafico/grafico.component';

@Component({
  selector: 'app-lista-resumo',
  standalone: true,
  imports: [CommonModule, GraficoComponent],
  templateUrl: './lista-resumo.component.html',
  styleUrl: './lista-resumo.component.css'
})
export class ListaResumoComponent {
  @Input() selecionado: string = "";
  @Input() lista: any = [];
  @Output() selecionarItem = new EventEmitter();

  get receita(): number {
    return this.lista.find((item: any) => item.label.includes('Receita'))?.value || 0;
  }

  get despesa(): number {
    return this.lista.find((item: any) => item.label.includes('Despesa'))?.value || 0;
  }

  get investimento(): number {
    return this.lista.find((item: any) => item.label.includes('Investimento'))?.value || 0;
  }

  selecionar(id: string) {
    this.selecionarItem.emit(id);
  }
}

