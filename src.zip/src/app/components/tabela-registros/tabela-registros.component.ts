import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-tabela-registros',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './tabela-registros.component.html',
  styleUrls: ['./tabela-registros.component.css']
})
export class TabelaRegistrosComponent {
  @Input() tabela: any[] = [];
  @Output() excluirItem = new EventEmitter();

  excluir(id: string) {
    this.excluirItem.emit(id);
  }
}