import { v4 as uuidv4 } from 'uuid';

export const LANCAMENTOS_MOCK = [
  { id: uuidv4(), descricao: "Venda de curso online", tipo: "Entrada", categoria: "Receitas", valor: 1200.00, data: new Date() },
  { id: uuidv4(), descricao: "Compra de material de escritório", tipo: "Saída", categoria: "Despesas", valor: 250.50, data: new Date() },
  { id: uuidv4(), descricao: "Aporte em ações de tecnologia", tipo: "Investimento", categoria: "Investimentos", valor: 1800.00, data: new Date() },
  { id: uuidv4(), descricao: "Serviço de consultoria", tipo: "Entrada", categoria: "Receitas", valor: 950.00, data: new Date() },
  { id: uuidv4(), descricao: "Pagamento de aluguel", tipo: "Saída", categoria: "Despesas", valor: 2200.00, data: new Date() },
  { id: uuidv4(), descricao: "Investimento em fundo imobiliário", tipo: "Investimento", categoria: "Investimentos", valor: 2000.00, data: new Date() },
  { id: uuidv4(), descricao: "Venda de produto físico", tipo: "Entrada", categoria: "Receitas", valor: 450.00, data: new Date() },
  { id: uuidv4(), descricao: "Conta de energia", tipo: "Saída", categoria: "Despesas", valor: 320.40, data: new Date() },
  { id: uuidv4(), descricao: "Compra de criptomoeda", tipo: "Investimento", categoria: "Investimentos", valor: 1000.00, data: new Date() },
  { id: uuidv4(), descricao: "Prestação de serviço técnico", tipo: "Entrada", categoria: "Receitas", valor: 700.00, data: new Date() },
  { id: uuidv4(), descricao: "Despesa com marketing digital", tipo: "Saída", categoria: "Despesas", valor: 600.00, data: new Date() },
  { id: uuidv4(), descricao: "Aplicação em CDB", tipo: "Investimento", categoria: "Investimentos", valor: 1500.00, data: new Date() },
  { id: uuidv4(), descricao: "Venda de assinatura mensal", tipo: "Entrada", categoria: "Receitas", valor: 300.00, data: new Date() },
  { id: uuidv4(), descricao: "Compra de equipamentos", tipo: "Saída", categoria: "Despesas", valor: 3500.00, data: new Date() },
  { id: uuidv4(), descricao: "Investimento em startup", tipo: "Investimento", categoria: "Investimentos", valor: 5000.00, data: new Date() },
  { id: uuidv4(), descricao: "Receita de royalties", tipo: "Entrada", categoria: "Receitas", valor: 800.00, data: new Date() },
  { id: uuidv4(), descricao: "Pagamento de impostos", tipo: "Saída", categoria: "Despesas", valor: 1200.00, data: new Date() },
  { id: uuidv4(), descricao: "Compra de títulos públicos", tipo: "Investimento", categoria: "Investimentos", valor: 2500.00, data: new Date() },
  { id: uuidv4(), descricao: "Venda de consultoria premium", tipo: "Entrada", categoria: "Receitas", valor: 2200.00, data: new Date() },
  { id: uuidv4(), descricao: "Despesa com transporte", tipo: "Saída", categoria: "Despesas", valor: 150.00, data: new Date() }
];
