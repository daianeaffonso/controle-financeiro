import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { v4 as uuidv4 } from 'uuid';
import { ListaResumoComponent } from '../../components/lista-resumo/lista-resumo.component';
import { TabelaRegistrosComponent } from '../../components/tabela-registros/tabela-registros.component';
import { LANCAMENTOS_MOCK } from '../../mocks/receitas.mock';
import { FormularioComponent } from '../../components/formulario/formulario.component';

@Component({
  selector: 'app-controle-financeiro',
  standalone: true,
  imports: [CommonModule, ListaResumoComponent, TabelaRegistrosComponent, FormularioComponent],
  templateUrl: './controle-financeiro.component.html',
  styleUrls: ['./controle-financeiro.component.css']
})
export class ControleFinanceiroComponent {
  itemSelecionado: string = ""; 
  listaResumos: any[] = [];
  // fonte de verdade (todos os registros)
  registrosOriginais: any[] = [];
  // tabela visível (pode ser filtrada)
  tabelaRegistros: any[] = [];

  /* inicial com base no Mock */
  ngOnInit(): void {
    this.registrosOriginais = [...LANCAMENTOS_MOCK];
    this.tabelaRegistros = [...this.registrosOriginais];
    this.atualizarResumos();
  }


  selecionarItem(id: string) {
    // encontrar o resumo clicado para descobrir qual categoria representa
    if (this.itemSelecionado === id) {
      // desmarcar -> mostrar todos
      this.itemSelecionado = "";
      this.tabelaRegistros = [...this.registrosOriginais];
    } else {
      this.itemSelecionado = id;
      const resumo = this.listaResumos.find(r => r.id === id);
      const label = resumo?.label || '';
      let categoriaFiltro = '';
      if (label.includes('Receita')) categoriaFiltro = 'Receitas';
      else if (label.includes('Despesa')) categoriaFiltro = 'Despesas';
      else if (label.includes('Investimento')) categoriaFiltro = 'Investimentos';

      if (categoriaFiltro) {
        this.tabelaRegistros = this.registrosOriginais.filter(registro => registro.categoria === categoriaFiltro);
      } else {
        this.tabelaRegistros = [...this.registrosOriginais];
      }
    }
  }

  adicionarRegistro(registro: any) {
    if (!registro || !registro.descricao || registro.valor === null) {
      return;
    } else {
        const novo = {
          id: uuidv4(),
          descricao: registro.descricao,
          tipo: registro.tipo,
          categoria: registro.tipo === 'Entrada' ? 'Receitas' : registro.tipo === 'Saída' ? 'Despesas' : 'Investimentos',
          valor: registro.valor,
          data: new Date()
        };

        // atualizar fonte original e aplicar filtro atual (se houver)
        this.registrosOriginais = [...this.registrosOriginais, novo];
        // reaplica o filtro atual
        if (this.itemSelecionado) {
          // se estiver filtrado, reaplica através de selecionarItem logic: find label
          const resumo = this.listaResumos.find(r => r.id === this.itemSelecionado);
          const label = resumo?.label || '';
          let categoriaFiltro = '';
          if (label.includes('Receita')) categoriaFiltro = 'Receitas';
          else if (label.includes('Despesa')) categoriaFiltro = 'Despesas';
          else if (label.includes('Investimento')) categoriaFiltro = 'Investimentos';

          if (categoriaFiltro) {
            this.tabelaRegistros = this.registrosOriginais.filter(registro => registro.categoria === categoriaFiltro);
          } else {
            this.tabelaRegistros = [...this.registrosOriginais];
          }
        } else {
          this.tabelaRegistros = [...this.registrosOriginais];
        }

        this.atualizarResumos();
  }
  }

  excluir(id: string) {
    // remover da fonte original e reaplicar filtro
    this.registrosOriginais = this.registrosOriginais.filter(registro => registro.id !== id);
    if (this.itemSelecionado) {
      const resumo = this.listaResumos.find(r => r.id === this.itemSelecionado);
      const label = resumo?.label || '';
      let categoriaFiltro = '';
      if (label.includes('Receita')) categoriaFiltro = 'Receitas';
      else if (label.includes('Despesa')) categoriaFiltro = 'Despesas';
      else if (label.includes('Investimento')) categoriaFiltro = 'Investimentos';

      if (categoriaFiltro) {
        this.tabelaRegistros = this.registrosOriginais.filter(registro => registro.categoria === categoriaFiltro);
      } else {
        this.tabelaRegistros = [...this.registrosOriginais];
      }
    } else {
      this.tabelaRegistros = [...this.registrosOriginais];
    }

    this.atualizarResumos();
  }

  /* Atualiza os resumos com base nos registros atuais */
  atualizarResumos() {
    this.listaResumos = [
      {id: uuidv4(),
      label: "Total de Receitas",
      value: this.registrosOriginais.reduce((acc, registro) => registro.tipo === "Entrada" ? acc + registro.valor : acc, 0)
      },
      {id: uuidv4(),
      label: "Total de Despesas",
      value: this.registrosOriginais.reduce((acc, registro) => registro.tipo === "Saída" ? acc + registro.valor : acc, 0)
      },
      {id: uuidv4(),
      label: "Total de Investimentos",
      value: this.registrosOriginais.reduce((acc, registro) => registro.tipo === "Investimento" ? acc + registro.valor : acc, 0)
      },
      {id: uuidv4(), 
      label: "Saldo Atual (Receitas - Despesas)", 
      value: this.registrosOriginais.reduce((acc, registro) => {
        if (registro.tipo === "Entrada") {
          return acc + registro.valor;
        } else if (registro.tipo === "Saída") {
          return acc - registro.valor;
        } else {
          return acc;
        }
      }, 0)
    },
    ];
  }
}
