import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'tipoCor',
  standalone: true   // ✅ permite usar direto em imports de componentes standalone
})
export class TipoCorPipe implements PipeTransform {
  transform(tipo: string): string {
    switch (tipo) {
      case 'Entrada':
        return '#27ae60'; // verde
      case 'Saída':
        return '#e74c3c'; // vermelho
      case 'Investimento':
        return '#2980b9'; // azul
      default:
        return '#2c3e50'; // cor padrão
    }
  }
}
